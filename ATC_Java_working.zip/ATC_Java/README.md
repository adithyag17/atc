# ATC_Java
Air traffic control system completely implemented in java
